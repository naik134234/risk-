import React, { useState, useEffect, useCallback } from 'react';
import { generateMarketData, getHistoricalAnalysis, generateCorrelationMatrix } from './services/geminiService';
import type { MarketData, PortfolioStock, Alert, Scenario, ModelComplexity, AnalysisMode, ChatMessage } from './types';
import { NIFTY_50_STOCKS_WITH_SECTORS } from './constants';
import Header from './components/Header';
import NiftyChart from './components/NiftyChart';
import RiskMetricsPanel from './components/RiskMetricsPanel';
import AlertsPanel from './components/AlertsPanel';
import MarketAnalysisPanel from './components/MarketAnalysisPanel';
import PortfolioPanel from './components/PortfolioPanel';
import LoadingOverlay from './components/LoadingOverlay';
import { processGeneratedData } from './services/dataProcessor';
import { convertToCSV, convertToHTML } from './services/downloadService';
import MarketPulsePanel from './components/MarketPulsePanel';
import LossDistributionChart from './components/LossDistributionChart';
import MarketSentimentPanel from './components/MarketSentimentPanel';
import CorrelationMatrix from './components/CorrelationMatrix';
import ChatPanel from './components/ChatPanel';
import { GoogleGenAI, Chat } from "@google/genai";

type DownloadFormat = 'json' | 'excel' | 'html';

const App: React.FC = () => {
    const [marketData, setMarketData] = useState<MarketData | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

    // User-configurable settings
    const [analysisMode, setAnalysisMode] = useState<AnalysisMode>('simulation');
    const [historicalPeriod, setHistoricalPeriod] = useState<number>(60);
    const [confidenceLevel, setConfidenceLevel] = useState<number>(95);
    const [scenario, setScenario] = useState<Scenario>('normal');
    const [modelComplexity, setModelComplexity] = useState<ModelComplexity>('balanced');
    const [portfolioStocks, setPortfolioStocks] = useState<PortfolioStock[]>([]);
    const [alerts, setAlerts] = useState<Alert[]>([]);
    const [autoRefresh, setAutoRefresh] = useState<boolean>(false);
    const [isAnalyzingPortfolio, setIsAnalyzingPortfolio] = useState<boolean>(false);

    // New state for Conversational AI Chat
    const [chat, setChat] = useState<Chat | null>(null);
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
    const [isChatting, setIsChatting] = useState<boolean>(false);
    const [chatError, setChatError] = useState<string | null>(null);

    useEffect(() => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const chatSession = ai.chats.create({
          model: 'gemini-2.5-flash',
          config: {
            systemInstruction: `You are a world-class financial analyst AI, embedded in an advanced risk management dashboard for the NIFTY 50. Your name is 'NIFTY-AI'. Your purpose is to provide users with expert-level, real-time analysis of market trends, economic data, and stock-specific information. You MUST use markdown for formatting like lists, and bolding key terms (**term**). Keep your responses concise yet insightful.`,
          },
        });
        setChat(chatSession);
        setChatHistory([
            { role: 'model', parts: "Hello! I'm NIFTY-AI, your personal financial analyst. How can I help you analyze the market today?" }
        ]);
    }, []);

    const handleSendMessage = useCallback(async (message: string) => {
        if (!chat || isChatting) return;

        setIsChatting(true);
        setChatError(null);
        const userMessage: ChatMessage = { role: 'user', parts: message };
        setChatHistory(prev => [...prev, userMessage]);

        try {
            const stream = await chat.sendMessageStream({ message });

            let modelResponse = "";
            setChatHistory(prev => [...prev, { role: 'model', parts: "" }]);

            for await (const chunk of stream) {
                modelResponse += chunk.text;
                setChatHistory(prev => {
                    const newHistory = [...prev];
                    newHistory[newHistory.length - 1] = { role: 'model', parts: modelResponse };
                    return newHistory;
                });
            }
        } catch (err) {
            const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
            setChatError(errorMsg);
            setChatHistory(prev => {
                 const newHistory = [...prev];
                 newHistory[newHistory.length - 1] = { role: 'model', parts: `Sorry, I encountered an error: ${errorMsg}` };
                 return newHistory;
            });
        } finally {
            setIsChatting(false);
        }
    }, [chat, isChatting]);


    const handleAnalysis = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const rawData = analysisMode === 'simulation'
                ? await generateMarketData({
                    days: historicalPeriod,
                    scenario,
                    complexity: modelComplexity,
                })
                : await getHistoricalAnalysis({
                    days: historicalPeriod,
                });
            
            const processedData = processGeneratedData(rawData, {
                days: historicalPeriod,
                confidenceLevel,
                scenario,
                complexity: modelComplexity,
            });

            setMarketData(processedData);
            setAlerts(processedData.alerts);
            setLastUpdated(new Date());

        } catch (err) {
            console.error("Failed to generate or process market data:", err);
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    }, [analysisMode, historicalPeriod, confidenceLevel, scenario, modelComplexity]);

    const handlePortfolioAnalysis = useCallback(async () => {
        if (portfolioStocks.length < 2) {
            setError("Please select at least two stocks to analyze correlation.");
            return;
        };

        setIsAnalyzingPortfolio(true);
        setError(null);
        
        try {
            const newCorrelationMatrix = await generateCorrelationMatrix(portfolioStocks);
            setMarketData(prevData => {
                if (!prevData) {
                    setError("Initial market data must be generated first.");
                    return null;
                }
                return {
                    ...prevData,
                    correlationMatrix: newCorrelationMatrix,
                };
            });
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to analyze portfolio correlation.");
        } finally {
            setIsAnalyzingPortfolio(false);
        }
    }, [portfolioStocks]);

    useEffect(() => {
        handleAnalysis();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Run only on initial load

    useEffect(() => {
        if (autoRefresh) {
            const intervalId = setInterval(() => {
                handleAnalysis();
            }, 300000); // 5 minutes
            return () => clearInterval(intervalId);
        }
    }, [autoRefresh, handleAnalysis]);

    const handleClearAlerts = () => {
        setAlerts([]);
    };

    const handleDownload = (format: DownloadFormat) => {
        if (!marketData) return;

        let blob: Blob;
        let filename: string;
        const date = new Date().toISOString().split('T')[0];
        const reportName = `NIFTY_50_Risk_Report_${analysisMode === 'simulation' ? scenario : 'historical'}_${date}`;

        try {
            switch (format) {
                case 'excel':
                    const csvData = convertToCSV(marketData);
                    blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
                    filename = `${reportName}.csv`;
                    break;
                case 'html':
                    const htmlData = convertToHTML(marketData);
                    blob = new Blob([htmlData], { type: 'text/html;charset=utf-8;' });
                    filename = `${reportName}.html`;
                    break;
                case 'json':
                default:
                    const jsonData = JSON.stringify(marketData, null, 2);
                    blob = new Blob([jsonData], { type: 'application/json' });
                    filename = `${reportName}.json`;
                    break;
            }

            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (downloadError) {
            console.error(`Failed to generate ${format} report:`, downloadError);
            setError(downloadError instanceof Error ? downloadError.message : "An unknown error occurred during download.");
        }
    };

    return (
        <div className="max-w-8xl mx-auto p-4 md:p-8">
            {isLoading && <LoadingOverlay analysisMode={analysisMode} />}
            {error && <div className="fixed top-4 right-4 bg-red-500 text-white p-4 rounded-lg shadow-lg z-50">{error}</div>}
            
            <Header onDownload={handleDownload} isDownloadDisabled={!marketData} scenario={scenario} analysisMode={analysisMode} />

            <main className="grid grid-cols-1 lg:grid-cols-4 xl:grid-cols-5 gap-8">
                {/* Main Content Area */}
                <div className="lg:col-span-3 xl:col-span-4 space-y-8">
                    {marketData && (
                        <>
                            <NiftyChart data={marketData} />
                            <PortfolioPanel
                                niftyStocks={NIFTY_50_STOCKS_WITH_SECTORS}
                                selectedStocks={portfolioStocks}
                                setSelectedStocks={setPortfolioStocks}
                                marketData={marketData}
                                onAnalyzePortfolio={handlePortfolioAnalysis}
                                isAnalyzingPortfolio={isAnalyzingPortfolio}
                                confidenceLevel={confidenceLevel}
                            />
                            <CorrelationMatrix marketData={marketData} />
                            <LossDistributionChart data={marketData} />
                        </>
                    )}
                </div>

                {/* Right Sidebar */}
                <div className="lg:col-span-1 xl:col-span-1 space-y-8">
                    {marketData && <MarketSentimentPanel sentiment={marketData.marketSentiment} />}
                    <RiskMetricsPanel
                        marketData={marketData}
                        settings={{ historicalPeriod, confidenceLevel, scenario, modelComplexity, analysisMode }}
                        setSettings={{ setHistoricalPeriod, setConfidenceLevel, setScenario, setModelComplexity, setAnalysisMode }}
                        onAnalyze={handleAnalysis}
                        autoRefresh={autoRefresh}
                        setAutoRefresh={setAutoRefresh}
                        lastUpdated={lastUpdated}
                    />
                    <AlertsPanel alerts={alerts} onClear={handleClearAlerts} />
                    <ChatPanel
                        history={chatHistory}
                        isChatting={isChatting}
                        onSendMessage={handleSendMessage}
                        error={chatError}
                        onClearChat={() => {
                            setChatHistory([{ role: 'model', parts: "Hello! I'm NIFTY-AI. How can I assist you?" }])
                            setChatError(null);
                        }}
                    />
                     {marketData && (
                        <>
                            <MarketAnalysisPanel marketData={marketData} />
                            <MarketPulsePanel marketData={marketData} />
                        </>
                    )}
                </div>
            </main>
        </div>
    );
};

export default App;