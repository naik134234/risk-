import type { GoogleGenAI, Type } from "@google/genai";

// Types for user-configurable settings
export type Scenario = 'normal' | 'bullish' | 'bearish' | 'volatile';
export type RiskAppetite = 'conservative' | 'moderate' | 'aggressive';
export type Distribution = 'normal' | "student_t";
export type ModelComplexity = 'fast' | 'balanced' | 'deep';
export type AnalysisMode = 'simulation' | 'historical';

// Type for a single stock
export interface Stock {
    name: string;
    sector: string;
}

// Type for a stock within a user's portfolio
export interface PortfolioStock extends Stock {
    weight: number;
}

// Type for generated alerts
export interface Alert {
    type: 'info' | 'warning' | 'critical';
    message: string;
    timestamp: string;
}

// Type for individual performance data points
export interface PerformanceDataPoint {
    day: number;
    price: number;
    volatility: number; // Realized volatility
    impliedVolatility: number;
}

// Type for the hybrid model's prediction
export interface HybridEnsemblePrediction {
    name: string; // e.g., 'Hybrid Ensemble Model'
    predictedVolatility: number;
    mse: number;
    rmse: number;
    mae: number;
}

// Type for feature importance
export interface FeatureImportance {
    name:string;
    value: number; // Percentage
}

// Type for risk metrics
export interface RiskMetrics {
    historicVaR: number;
    historicCVaR: number;
    monteCarloVaR: number;
    monteCarloCVaR: number;
    modelVaR: number;
    modelCVaR: number;
}

export interface BacktestingResult {
    varHitRate: number;
    expectedHitRate: number;
    kupiecPValue: number;
}

export interface MacroIndicator {
    cpi: number;
    repoRate: number;
    gdp: number;
}

export interface CorrelationMatrix {
    stocks: string[];
    matrix: number[][];
}

// The main data structure for the entire dashboard
export interface MarketData {
    performanceData: PerformanceDataPoint[];
    dailyReturns: number[];
    sma10: (number | null)[];
    riskMetrics: RiskMetrics;
    hybridEnsemblePrediction: HybridEnsemblePrediction;
    featureImportance: FeatureImportance[];
    backtesting: BacktestingResult;
    keyTakeaways: string;
    marketSentiment: string;
    marketEvents: string[];
    topPerformers: { name: string; change: number; sector: string }[];
    riskContribution: {
        bySector: { sector: string; contribution: number }[];
        byStock: { name: string; contribution: number }[];
    };
    macroIndicators: MacroIndicator;
    alerts: Alert[];
    lossDistribution: number[];
    correlationMatrix: CorrelationMatrix;
}

// A more robust structure for a single day's simulated data
export interface DailyDataPoint {
    change: number;
    realizedVol: number;
    impliedVol: number;
}

// Type for the raw data structure expected from Gemini
export interface RawMarketData {
    dailyData: DailyDataPoint[];
    hybridEnsemblePrediction: HybridEnsemblePrediction;
    featureImportance: FeatureImportance[];
    keyTakeaways: string;
    marketSentiment: string;
    marketEvents: string[];
    topPerformers: { name: string; change: number }[];
    riskContribution: {
        bySector: { sector: string; contribution: number }[];
        byStock: { name: string; contribution: number }[];
    };
    macroIndicators: MacroIndicator;
    correlationMatrix: CorrelationMatrix;
}

// Type for settings passed to generation and processing
export interface SimulationSettings {
    days: number;
    confidenceLevel: number;
    scenario: Scenario;
    complexity: ModelComplexity;
}

// Types for Conversational Chat
export interface ChatMessage {
    role: 'user' | 'model';
    parts: string;
}

// Types for Live Market Search Analysis
export interface GroundingSource {
    web: {
        uri: string;
        title: string;
    };
}
export interface AnalysisResult {
    text: string;
    sources: GroundingSource[];
}