import type { MarketData } from '../types';

const escapeCsvCell = (cellData: any): string => {
    const stringData = String(cellData ?? '');
    if (stringData.includes(',') || stringData.includes('"') || stringData.includes('\n')) {
        return `"${stringData.replace(/"/g, '""')}"`;
    }
    return stringData;
};

const toCsv = (headers: string[], rows: (string|number|null|undefined)[][]): string => {
    const headerRow = headers.map(escapeCsvCell).join(',');
    const contentRows = rows.map(row => row.map(escapeCsvCell).join(',')).join('\n');
    return `${headerRow}\n${contentRows}`;
};

export const convertToCSV = (data: MarketData): string => {
    let csvContent = '';

    // Summary
    csvContent += 'Summary\n';
    csvContent += toCsv(['Metric', 'Value'], [
        ['Market Sentiment', data.marketSentiment],
        ['Key Takeaways', data.keyTakeaways],
    ]);
    csvContent += '\n\n';
    
    // Risk Metrics
    csvContent += 'Risk Metrics\n';
    csvContent += toCsv(['Metric', 'Value (%)'], Object.entries(data.riskMetrics).map(([key, value]) => [key, value]));
    csvContent += '\n\n';

    // Model Performance
    csvContent += 'Model Performance\n';
    const m = data.hybridEnsemblePrediction;
    csvContent += toCsv(
        ['Model', 'Predicted Volatility (%)', 'MSE', 'RMSE', 'MAE'], 
        [[m.name, m.predictedVolatility, m.mse, m.rmse, m.mae]]
    );
    csvContent += '\n\n';

    // Backtesting
    csvContent += 'VaR Backtesting\n';
    csvContent += toCsv(['Metric', 'Value'], Object.entries(data.backtesting).map(([key, value]) => [key, value]));
    csvContent += '\n\n';

    // Performance Data
    csvContent += 'NIFTY 50 Performance Data\n';
    csvContent += toCsv(
        ['Day', 'Price (₹)', 'Realized Volatility (%)', 'Implied Volatility (%)', '10-Day SMA (₹)'], 
        data.performanceData.map((p, i) => [p.day, p.price, p.volatility, p.impliedVolatility, data.sma10[i]])
    );
    csvContent += '\n\n';

    // Top Performers
    csvContent += 'Top Performers\n';
    csvContent += toCsv(
        ['Stock', 'Sector', 'Change (%)'], 
        data.topPerformers.map(p => [p.name, p.sector, p.change])
    );
    csvContent += '\n\n';

    // Risk Contribution
    csvContent += 'Risk Contribution by Sector\n';
    csvContent += toCsv(['Sector', 'Contribution (%)'], data.riskContribution.bySector.map(s => [s.sector, s.contribution]));
    csvContent += '\n';
    csvContent += 'Risk Contribution by Stock\n';
    csvContent += toCsv(['Stock', 'Contribution (%)'], data.riskContribution.byStock.map(s => [s.name, s.contribution]));
    csvContent += '\n\n';
    
    return csvContent;
};

export const convertToHTML = (data: MarketData): string => {
    const head = `
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>NIFTY 50 Risk Report</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 0; background-color: #f9fafb; color: #111827; }
                .container { max-width: 1024px; margin: auto; padding: 24px; }
                .card { background-color: white; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1); padding: 24px; margin-bottom: 24px; }
                h1 { font-size: 2.25rem; font-weight: 800; color: #1f2937; margin-bottom: 8px; }
                h2 { font-size: 1.5rem; font-weight: 700; color: #374151; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px; margin-top: 24px; margin-bottom: 16px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { text-align: left; padding: 12px; border-bottom: 1px solid #e5e7eb; }
                th { background-color: #f3f4f6; font-weight: 600; }
                tr:nth-child(even) { background-color: #f9fafb; }
                p { line-height: 1.6; }
                ul { list-style-position: inside; padding-left: 0; }
                li { margin-bottom: 8px; }
                .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 24px; }
                .metric-card { text-align: center; }
                .metric-label { font-size: 0.875rem; color: #6b7280; }
                .metric-value { font-size: 2rem; font-weight: 700; color: #dc2626; }
            </style>
        </head>
    `;

    const m = data.hybridEnsemblePrediction;
    const body = `
        <body>
            <div class="container">
                <div class="card">
                    <h1>NIFTY 50 Risk Management Report</h1>
                    <p>Generated on: ${new Date().toUTCString()}</p>
                    <p>Market Sentiment: <strong>${data.marketSentiment}</strong></p>
                </div>

                <div class="card">
                    <h2>Key Takeaways</h2>
                    <p>${data.keyTakeaways.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>
                </div>
                
                <div class="card">
                    <h2>Risk Metrics</h2>
                    <div class="grid">
                        ${Object.entries(data.riskMetrics).map(([key, value]) => `
                            <div class="metric-card">
                                <div class="metric-label">${key.replace(/([A-Z])/g, ' $1').trim()}</div>
                                <div class="metric-value">${typeof value === 'number' ? value.toFixed(2) : value}%</div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="card">
                    <h2>Model Performance</h2>
                    <table>
                        <thead><tr><th>Model</th><th>Predicted Volatility</th><th>MSE</th><th>RMSE</th><th>MAE</th></tr></thead>
                        <tbody>
                            <tr>
                                <td>${m.name}</td>
                                <td>${m.predictedVolatility.toFixed(2)}%</td>
                                <td>${m.mse.toFixed(4)}</td>
                                <td>${m.rmse.toFixed(4)}</td>
                                <td>${m.mae.toFixed(4)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="grid">
                    <div class="card">
                        <h2>Top Performers</h2>
                        <table>
                            <thead><tr><th>Stock</th><th>Change</th></tr></thead>
                            <tbody>
                                ${data.topPerformers.map(p => `
                                    <tr><td>${p.name}</td><td style="color:${p.change >= 0 ? '#16a34a' : '#dc2626'};">${p.change.toFixed(2)}%</td></tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div class="card">
                        <h2>Macro Indicators</h2>
                        <table>
                            <thead><tr><th>Indicator</th><th>Value</th></tr></thead>
                            <tbody>
                                ${Object.entries(data.macroIndicators).map(([key, value]) => `
                                    <tr><td>${key.toUpperCase()}</td><td>${value}%</td></tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card">
                    <h2>NIFTY 50 Historical Performance</h2>
                    <table>
                        <thead><tr><th>Day</th><th>Price (₹)</th><th>Realized Volatility (%)</th><th>Implied Volatility (%)</th><th>10-Day SMA (₹)</th></tr></thead>
                        <tbody>
                            ${data.performanceData.map((p, i) => `
                                <tr>
                                    <td>${p.day}</td>
                                    <td>${p.price.toLocaleString('en-IN')}</td>
                                    <td>${p.volatility.toFixed(2)}</td>
                                    <td>${p.impliedVolatility.toFixed(2)}</td>
                                    <td>${data.sma10[i] ? data.sma10[i]?.toLocaleString('en-IN') : 'N/A'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </body>
    `;

    return `<!DOCTYPE html><html lang="en">${head}${body}</html>`;
};