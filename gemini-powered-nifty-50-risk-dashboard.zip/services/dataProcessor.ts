import type { RawMarketData, MarketData, SimulationSettings, Alert, BacktestingResult } from '../types';
import { NIFTY_50_STOCKS_WITH_SECTORS } from '../constants';

// --- Core Risk Calculation Functions ---

function calculateHistoricVaRCVaR(dailyReturns: number[], confidenceLevel: number) {
    const dailyLosses = dailyReturns.map(r => -r * 100);
    dailyLosses.sort((a, b) => b - a);

    const varIndex = Math.ceil(dailyLosses.length * (1 - confidenceLevel / 100)) - 1;
    const varValue = dailyLosses[varIndex > -1 ? varIndex : 0] || 0;

    const cvarLosses = dailyLosses.filter(loss => loss >= varValue);
    const cvarValue = cvarLosses.length > 0 ? cvarLosses.reduce((sum, loss) => sum + loss, 0) / cvarLosses.length : varValue;

    return {
        varValue: parseFloat(varValue.toFixed(2)),
        cvarValue: parseFloat(cvarValue.toFixed(2))
    };
}

function calculateMonteCarloVaRCVaR(historicalDailyReturns: number[], numSimulations: number, confidenceLevel: number) {
    const simulatedLosses: number[] = [];

    if (historicalDailyReturns.length === 0) {
        return { varValue: 0, cvarValue: 0, lossDistribution: [] };
    }

    // This is a 1-day historical simulation for VaR.
    // For each simulation, we pick one random day from history to represent a possible outcome for the next day.
    for (let i = 0; i < numSimulations; i++) {
        const randomReturn = historicalDailyReturns[Math.floor(Math.random() * historicalDailyReturns.length)];
        const loss = -randomReturn * 100; // Convert to percentage loss
        simulatedLosses.push(loss);
    }

    simulatedLosses.sort((a, b) => b - a);
    const varIndex = Math.ceil(simulatedLosses.length * (1 - confidenceLevel / 100)) - 1;
    const varValue = simulatedLosses[varIndex > -1 ? varIndex : 0] || 0;
    
    const cvarLosses = simulatedLosses.filter(loss => loss >= varValue);
    const cvarValue = cvarLosses.length > 0 ? cvarLosses.reduce((sum, loss) => sum + loss, 0) / cvarLosses.length : varValue;

    return {
        varValue: parseFloat(varValue.toFixed(2)),
        cvarValue: parseFloat(cvarValue.toFixed(2)),
        lossDistribution: simulatedLosses,
    };
}

function calculateModelVaRCVaR(predictedVolatility: number, confidenceLevel: number) {
    let zScore: number;
    let alpha: number;

    switch (confidenceLevel) {
        case 99:
            zScore = 2.326;
            alpha = 0.99;
            break;
        case 95:
            zScore = 1.645;
            alpha = 0.95;
            break;
        case 90:
        default:
            zScore = 1.282;
            alpha = 0.90;
            break;
    }

    // The model's predicted volatility is assumed to be an ANNUALIZED percentage.
    // Convert it to daily volatility to calculate daily VaR.
    // There are approximately 252 trading days in a year.
    const dailyVolatility = predictedVolatility / Math.sqrt(252);

    const modelVaR = dailyVolatility * zScore;

    // CVaR for normal distribution: sigma * pdf(z_score) / (1 - alpha)
    const pdf_z = (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * zScore * zScore);
    const modelCVaR = dailyVolatility * (pdf_z / (1 - alpha));

    return {
        varValue: parseFloat(modelVaR.toFixed(2)),
        cvarValue: parseFloat(modelCVaR.toFixed(2))
    };
}


function calculateKupiecTest(actualLosses: number[], varValues: number[], confidenceLevel: number): BacktestingResult {
    const numObservations = actualLosses.length;
    let observedBreaches = 0;

    for (let i = 0; i < numObservations; i++) {
        if (actualLosses[i] > varValues[i]) {
            observedBreaches++;
        }
    }
    
    const varHitRate = numObservations > 0 ? (observedBreaches / numObservations) * 100 : 0;
    const expectedHitRate = 100 - confidenceLevel;

    // A more stable, deterministic (though not statistically rigorous) p-value calculation for demonstration.
    // It is based on the relative deviation from the expected hit rate.
    const deviation = Math.abs(varHitRate - expectedHitRate) / (expectedHitRate || 1);
    let pValue;
    if (deviation < 0.25) { // Very close
        pValue = 0.85;
    } else if (deviation < 0.5) { // Moderately close
        pValue = 0.40;
    } else if (deviation < 1.0) { // Deviating significantly
        pValue = 0.15;
    } else { // Large deviation, likely fails the test
        pValue = 0.04;
    }

    return {
        varHitRate: parseFloat(varHitRate.toFixed(2)),
        expectedHitRate: expectedHitRate,
        kupiecPValue: parseFloat(pValue.toFixed(3)),
    };
}

// --- Data Transformation and Processing ---

function generatePerformanceData(dailyChanges: number[], realizedVolatility: number[], impliedVolatility: number[]) {
    let currentPrice = 18000;
    const performanceData = dailyChanges.map((change, index) => {
        currentPrice *= (1 + change / 100);
        return {
            day: index + 1,
            price: parseFloat(currentPrice.toFixed(2)),
            volatility: realizedVolatility[index], // Realized volatility
            impliedVolatility: impliedVolatility[index],
        };
    });
    return performanceData;
}

function calculateSMA(data: number[], period: number) {
    const sma: (number | null)[] = [];
    for (let i = 0; i < data.length; i++) {
        if (i < period - 1) {
            sma.push(null);
        } else {
            const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
            sma.push(parseFloat((sum / period).toFixed(2)));
        }
    }
    return sma;
}

function generateAlerts(marketData: MarketData): Alert[] {
    const newAlerts: Alert[] = [];
    const timestamp = new Date().toLocaleTimeString();

    if (marketData.riskMetrics.historicVaR > 3.5) {
        newAlerts.push({ message: `Critical: High Historic VaR detected at ${marketData.riskMetrics.historicVaR}%! Review portfolio exposure.`, type: 'critical', timestamp });
    } else if (marketData.riskMetrics.historicVaR > 2.5) {
        newAlerts.push({ message: `Warning: Historic VaR is elevated at ${marketData.riskMetrics.historicVaR}%. Monitor conditions.`, type: 'warning', timestamp });
    }

    const latestVolatility = marketData.performanceData[marketData.performanceData.length - 1]?.volatility;
    if (latestVolatility > 1.8) {
        newAlerts.push({ message: `Critical: High volatility detected (${latestVolatility}%).`, type: 'critical', timestamp });
    }

    if (marketData.marketSentiment.toLowerCase().includes('negative') || marketData.marketSentiment.toLowerCase().includes('bearish')) {
        newAlerts.push({ message: `Warning: Market sentiment is ${marketData.marketSentiment}.`, type: 'warning', timestamp });
    }
    
    if (newAlerts.length === 0) {
        newAlerts.push({ message: `Info: Market conditions appear stable.`, type: 'info', timestamp });
    }

    return newAlerts;
}

export function processGeneratedData(rawData: RawMarketData, settings: SimulationSettings): MarketData {
    // 1. Extract data from the more robust dailyData structure
    const niftyDailyChanges = rawData.dailyData.map(d => d.change);
    const realizedVolatility = rawData.dailyData.map(d => d.realizedVol);
    const impliedVolatility = rawData.dailyData.map(d => d.impliedVol);
    
    // 2. Process performance data
    const performanceData = generatePerformanceData(niftyDailyChanges, realizedVolatility, impliedVolatility);
    
    const prices = performanceData.map(d => d.price);
    const sma10 = calculateSMA(prices, 10);

    // 3. Calculate risk metrics
    const dailyReturns = niftyDailyChanges.map(c => c / 100);
    const historicResults = calculateHistoricVaRCVaR(dailyReturns, settings.confidenceLevel);
    const monteCarloResults = calculateMonteCarloVaRCVaR(dailyReturns, 10000, settings.confidenceLevel);
    
    const modelPrediction = rawData.hybridEnsemblePrediction;
    const modelResults = modelPrediction 
        ? calculateModelVaRCVaR(modelPrediction.predictedVolatility, settings.confidenceLevel) 
        : { varValue: 0, cvarValue: 0 };

    const riskMetrics = {
        historicVaR: historicResults.varValue,
        historicCVaR: historicResults.cvarValue,
        monteCarloVaR: monteCarloResults.varValue,
        monteCarloCVaR: monteCarloResults.cvarValue,
        modelVaR: modelResults.varValue,
        modelCVaR: modelResults.cvarValue,
    };
    
    // 4. Process backtesting
    const actualLosses = dailyReturns.map(r => -r * 100);
    // Use historic VaR as the threshold for backtesting for simplicity
    const varValues = Array(settings.days).fill(riskMetrics.historicVaR); 
    const backtesting = calculateKupiecTest(actualLosses, varValues, settings.confidenceLevel);
    
    // 5. Combine top performers with sectors
    const topPerformers = rawData.topPerformers.map(performer => {
        const stockInfo = NIFTY_50_STOCKS_WITH_SECTORS.find(s => s.name === performer.name);
        return {
            ...performer,
            sector: stockInfo ? stockInfo.sector : 'Unknown'
        };
    });

    // 6. Assemble final MarketData object
    let marketData: MarketData = {
        performanceData,
        dailyReturns,
        sma10,
        riskMetrics,
        hybridEnsemblePrediction: rawData.hybridEnsemblePrediction,
        featureImportance: rawData.featureImportance,
        backtesting,
        keyTakeaways: rawData.keyTakeaways,
        marketSentiment: rawData.marketSentiment,
        marketEvents: rawData.marketEvents,
        topPerformers,
        riskContribution: rawData.riskContribution,
        macroIndicators: rawData.macroIndicators,
        alerts: [], // Will be generated next
        lossDistribution: monteCarloResults.lossDistribution,
        correlationMatrix: rawData.correlationMatrix,
    };

    // 7. Generate alerts based on the processed data
    marketData.alerts = generateAlerts(marketData);

    return marketData;
}