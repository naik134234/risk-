import { GoogleGenAI, Type } from "@google/genai";
import type { RawMarketData, Scenario, ModelComplexity, PortfolioStock, CorrelationMatrix } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        dailyData: {
            type: Type.ARRAY,
            description: "Array of daily simulated data points for the NIFTY 50 index. Each object in the array represents one day. The length of this array must match the requested number of days.",
            items: {
                type: Type.OBJECT,
                properties: {
                    change: { type: Type.NUMBER, description: "Simulated daily percentage change for the NIFTY 50 index." },
                    realizedVol: { type: Type.NUMBER, description: "Simulated daily *realized* volatility percentage for the corresponding day." },
                    impliedVol: { type: Type.NUMBER, description: "Simulated daily *implied* volatility percentage for the corresponding day." },
                },
                required: ["change", "realizedVol", "impliedVol"],
            }
        },
        hybridEnsemblePrediction: {
            type: Type.OBJECT,
            description: "Provide plausible performance metrics for a single, sophisticated Hybrid Ensemble Model (conceptually combining LSTM, ANN, DNN). The predicted volatility should be a realistic forecast for the next day, consistent with the scenario and model complexity.",
            properties: {
                name: { type: Type.STRING, description: "Model name. Should be 'Hybrid Ensemble'." },
                predictedVolatility: { type: Type.NUMBER, description: "A realistic predicted volatility percentage for the next trading day." },
                mse: { type: Type.NUMBER, description: "A plausible Mean Squared Error for the model's performance." },
                rmse: { type: Type.NUMBER, description: "A plausible Root Mean Squared Error for the model's performance." },
                mae: { type: Type.NUMBER, description: "A plausible Mean Absolute Error for the model's performance." },
            },
            required: ["name", "predictedVolatility", "mse", "rmse", "mae"],
        },
        featureImportance: {
            type: Type.ARRAY,
            description: "Analyze the key drivers of market movement for the simulated scenario and complexity. Sum of values should be 100.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    value: { type: Type.NUMBER, description: "Importance percentage." },
                },
                required: ["name", "value"],
            },
        },
        keyTakeaways: {
            type: Type.STRING,
            description: "A concise, insightful summary analyzing the market's simulated performance and key drivers for the specified scenario. Use markdown for bolding.",
        },
        marketSentiment: {
            type: Type.STRING,
            description: "Describe the overall market sentiment that reflects the chosen scenario (e.g., 'Strongly Bullish', 'Deeply Bearish', 'Extreme Volatility').",
        },
        marketEvents: {
            type: Type.ARRAY,
            description: "A list of 3-4 plausible, major market-moving events that would CAUSE the specified scenario.",
            items: { type: Type.STRING },
        },
        topPerformers: {
            type: Type.ARRAY,
            description: "List of top 5 performing NIFTY 50 stocks during this simulated period with their aggregate percentage change, reflecting the scenario.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    change: { type: Type.NUMBER },
                },
                required: ["name", "change"],
            },
        },
        riskContribution: {
            type: Type.OBJECT,
            properties: {
                bySector: {
                    type: Type.ARRAY,
                    description: "Risk contribution breakdown by top 5 sectors, based on their simulated volatility during the period.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            sector: { type: Type.STRING },
                            contribution: { type: Type.NUMBER, description: "Contribution percentage." },
                        },
                        required: ["sector", "contribution"],
                    },
                },
                byStock: {
                    type: Type.ARRAY,
                    description: "Risk contribution breakdown by top 5 individual stocks from the NIFTY 50, reflecting the scenario.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            contribution: { type: Type.NUMBER, description: "Contribution percentage." },
                        },
                        required: ["name", "contribution"],
                    },
                },
            },
            required: ["bySector", "byStock"],
        },
        macroIndicators: {
            type: Type.OBJECT,
            properties: {
                cpi: { type: Type.NUMBER, description: "The plausible Consumer Price Index (Inflation) percentage for the scenario." },
                repoRate: { type: Type.NUMBER, description: "The plausible RBI Repo Rate percentage for the scenario." },
                gdp: { type: Type.NUMBER, description: "The plausible GDP Growth percentage for the scenario." },
            },
            required: ["cpi", "repoRate", "gdp"],
        },
        correlationMatrix: {
            type: Type.OBJECT,
            description: "A correlation matrix for the top 5 risk-contributing stocks. Values should be between -1 and 1.",
            properties: {
                stocks: {
                    type: Type.ARRAY,
                    description: "An array of the 5 stock names, matching the 'byStock' risk contributors.",
                    items: { type: Type.STRING },
                },
                matrix: {
                    type: Type.ARRAY,
                    description: "A 5x5 matrix of correlation values. matrix[i][j] is the correlation between stocks[i] and stocks[j]. The diagonal (matrix[i][i]) must be 1.",
                    items: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER }
                    }
                }
            },
            required: ["stocks", "matrix"]
        }
    },
    required: ["dailyData", "hybridEnsemblePrediction", "featureImportance", "keyTakeaways", "marketSentiment", "marketEvents", "topPerformers", "riskContribution", "macroIndicators", "correlationMatrix"],
};


export const generateMarketData = async (
    { days, scenario, complexity }: { days: number; scenario: Scenario; complexity: ModelComplexity }
): Promise<RawMarketData> => {
    
    if (!scenario || typeof scenario !== 'string') {
        throw new Error(`Invalid 'scenario' provided to generateMarketData: ${scenario}`);
    }
    if (!complexity || typeof complexity !== 'string') {
        throw new Error(`Invalid 'complexity' provided to generateMarketData: ${complexity}`);
    }

    const systemInstruction = `You are a quantitative financial analyst (Quant) specializing in market risk simulation. Your purpose is to generate highly realistic, context-aware simulated data for the Indian stock market (NIFTY 50) for a risk management dashboard. You must adhere strictly to the provided JSON schema and the user's chosen scenario and model complexity. Ensure all arrays have the correct length and that the data logically and statistically reflects the specified market conditions. Do not return any text outside of the JSON object.`;
    
    const scenarioDescriptions = {
        normal: "This is a baseline scenario reflecting typical market conditions. Use real historical data patterns from the most recent period. Show moderate volatility and a mix of positive and negative days.",
        bullish: "Simulate a strong 'bullish rally' scenario. Show consistently positive daily returns, low realized and implied volatility, high investor confidence, and positive economic indicators. Market events should be favorable (e.g., strong corporate earnings, positive government policy, rate cuts).",
        bearish: "Simulate a 'bearish recession' scenario. Show consistently negative daily returns, high realized volatility (spikes), high implied volatility, negative investor sentiment, and poor economic indicators. Market events should be negative (e.g., geopolitical crisis, unexpected rate hikes, supply chain shocks, inverted yield curve).",
        volatile: "Simulate a 'high volatility' scenario with no clear trend. Show wild daily swings (both positive and negative), high realized volatility that often exceeds implied volatility, and a sentiment of extreme uncertainty. The net change over the period could be close to zero, but with significant turbulence."
    };

    const complexityDescriptions = {
        fast: "The model should be lightweight and highly reactive to recent price action, like a high-frequency trading model. Prioritize short-term momentum signals. The generated volatility should be spiky and feature importance should favor recent technical indicators.",
        balanced: "This is the default hybrid ensemble model. It balances short-term signals with medium-term fundamental drivers. This is a standard institutional-grade model with realistic, moderately persistent volatility.",
        deep: "The model should behave like a deep, strategic, long-term forecasting model. It should heavily weigh macroeconomic indicators, long-term trends, and fundamental analysis over short-term noise. Its predictions and generated volatility will be smoother and less reactive to daily noise."
    };

    const prompt = `Generate a detailed, simulated financial analysis for the NIFTY 50 index for a period of ${days} trading days.
    
    **CRITICAL INSTRUCTION: The simulation MUST adhere to the following market scenario: "${scenario.toUpperCase()}"**.
    **CRITICAL INSTRUCTION: The AI model's behavior MUST be configured for the following complexity: "${complexity.toUpperCase()}"**.
    
    Scenario details: ${scenarioDescriptions[scenario]}
    Model Complexity details: ${complexityDescriptions[complexity]}
    
    Structure the entire output according to the JSON schema. The 'dailyData' array must contain exactly ${days} objects, each representing a plausible simulation for one day under the given scenario and model complexity. The correlation matrix should be consistent with the behavior of the top risk-contributing stocks under the chosen scenario. All other fields must also be consistent.`;

    const config: any = {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.3, // Lowered for more predictable, "accurate" output
    };

    // For "fast" complexity, disable thinking to increase speed.
    // For "balanced" and "deep", allow default thinking for higher accuracy.
    if (complexity === 'fast') {
        config.thinkingConfig = { thinkingBudget: 0 };
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: config,
        });
        
        const jsonText = response.text.trim();
        const data: RawMarketData = JSON.parse(jsonText);

        // Basic validation
        if (data.dailyData.length !== days) {
            throw new Error(`Gemini response validation failed: Incorrect array length. Expected ${days} for dailyData array.`);
        }
        
        return data;

    } catch (error) {
        console.error("Error fetching data from Gemini:", error);
        throw new Error("Failed to generate data from AI. The model may have returned an invalid format. Please try again.");
    }
};


export const getHistoricalAnalysis = async ({ days }: { days: number; }): Promise<RawMarketData> => {
    const systemInstruction = `You are a quantitative financial analyst (Quant) specializing in market data analysis. Your purpose is to provide highly accurate, real historical data for the Indian stock market (NIFTY 50) and analyze it for a risk management dashboard. You must act as if you are querying a financial database like Yahoo Finance. Adhere strictly to the provided JSON schema. Ensure all data reflects the actual market conditions for the specified historical period. Do not return any text outside of the JSON object.`;

    const prompt = `Provide a detailed financial analysis based on the **actual historical data** for the NIFTY 50 index for the past ${days} trading days.
    
    **CRITICAL INSTRUCTION: DO NOT SIMULATE or INVENT data.** You must use your internal knowledge of real market history to populate the data fields.
    - \`dailyData\`: Provide the actual daily percentage changes, realized volatility, and implied volatility for the period.
    - All other fields (Key Takeaways, Market Sentiment, Events, Top Performers, etc.) must be a factual analysis of what occurred during that specific historical period.
    - Structure the entire output according to the JSON schema. The 'dailyData' array must contain exactly ${days} objects.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.2, // Low temperature to stick to facts
            },
        });
        
        const jsonText = response.text.trim();
        const data: RawMarketData = JSON.parse(jsonText);

        // Basic validation
        if (data.dailyData.length !== days) {
            throw new Error(`Gemini response validation failed: Incorrect array length. Expected ${days} for dailyData array.`);
        }
        
        return data;

    } catch (error) {
        console.error("Error fetching historical analysis from Gemini:", error);
        throw new Error("Failed to generate historical analysis from AI. The model may have returned an invalid format. Please try again.");
    }
};

export const generateCorrelationMatrix = async (portfolioStocks: PortfolioStock[]): Promise<CorrelationMatrix> => {
    if (!portfolioStocks || portfolioStocks.length < 2) {
        throw new Error("At least two stocks are required to generate a correlation matrix.");
    }
    
    const stockNames = portfolioStocks.map(s => s.name);

    const correlationSchema = {
        type: Type.OBJECT,
        properties: {
            stocks: {
                type: Type.ARRAY,
                description: `An array of stock names, matching the input portfolio order: [${stockNames.join(', ')}].`,
                items: { type: Type.STRING },
            },
            matrix: {
                type: Type.ARRAY,
                description: `A ${stockNames.length}x${stockNames.length} matrix of correlation values. matrix[i][j] is the correlation between stocks[i] and stocks[j]. The diagonal must be 1.`,
                items: {
                    type: Type.ARRAY,
                    items: { type: Type.NUMBER }
                }
            }
        },
        required: ["stocks", "matrix"]
    };

    const systemInstruction = `You are a quantitative financial analyst. Your task is to generate a correlation matrix for a given portfolio of stocks based on recent market behavior and data. Adhere strictly to the JSON schema.`;
    
    const prompt = `Generate a correlation matrix for the following stocks: [${stockNames.join(', ')}]. The 'stocks' array in the JSON response must match these names and order exactly. The matrix must be ${stockNames.length}x${stockNames.length}.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: correlationSchema,
                temperature: 0.2,
                thinkingConfig: { thinkingBudget: 0 }, // Disable thinking for faster response on this focused task
            },
        });
        
        const jsonText = response.text.trim();
        const data: CorrelationMatrix = JSON.parse(jsonText);
        
        // Basic validation
        if (data.stocks.length !== stockNames.length || data.matrix.length !== stockNames.length || data.matrix[0].length !== stockNames.length) {
            throw new Error(`Gemini response validation failed: Incorrect matrix dimensions.`);
        }

        return data;

    } catch (error) {
        console.error("Error fetching correlation matrix from Gemini:", error);
        throw new Error("Failed to generate correlation matrix from AI. The model may have returned an invalid format. Please try again.");
    }
};