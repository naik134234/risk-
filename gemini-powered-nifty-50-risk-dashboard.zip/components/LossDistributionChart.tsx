
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { MarketData } from '../types';
import Card from './Card';
import { PresentationChartBarIcon } from './Icons';

interface LossDistributionChartProps {
    data: MarketData;
}

const LossDistributionChart: React.FC<LossDistributionChartProps> = ({ data }) => {
    const chartData = useMemo(() => {
        const losses = data.lossDistribution;
        if (!losses || losses.length === 0) return [];

        const minLoss = Math.min(...losses);
        const maxLoss = Math.max(...losses);
        const numBins = 20;
        const binWidth = (maxLoss - minLoss) / numBins;

        const bins = Array(numBins).fill(0).map((_, i) => ({
            name: (minLoss + i * binWidth).toFixed(0),
            count: 0,
        }));

        losses.forEach(loss => {
            let binIndex = Math.floor((loss - minLoss) / binWidth);
            if (binIndex >= numBins) binIndex = numBins - 1;
            if (binIndex < 0) binIndex = 0;
            bins[binIndex].count++;
        });

        return bins;
    }, [data.lossDistribution]);

    return (
        <Card>
            <h2 className="text-xl font-bold text-slate-700 mb-4 flex items-center">
                <PresentationChartBarIcon className="w-6 h-6 mr-2" />
                Monte Carlo Loss Distribution
            </h2>
            <div className="h-80 w-full">
                <ResponsiveContainer>
                    <BarChart data={chartData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} unit="%" />
                        <YAxis tick={{ fill: '#64748b', fontSize: 12 }} />
                        <Tooltip
                            cursor={{ fill: 'rgba(79, 70, 229, 0.1)' }}
                            contentStyle={{
                                backgroundColor: 'rgba(255, 255, 255, 0.9)',
                                border: '1px solid #e2e8f0',
                                borderRadius: '0.5rem',
                            }}
                            labelStyle={{ fontWeight: 'bold' }}
                            formatter={(value: number, name, props) => [`${value} simulations`, `Loss > ${props.payload.name}%`]}
                        />
                        <Bar dataKey="count" fill="#4f46e5" name="Frequency" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </Card>
    );
};

export default LossDistributionChart;
