import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import type { MarketData } from '../types';
import Card from './Card';
import { ChartBarIcon, CpuChipIcon, DocumentCheckIcon } from './Icons';

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#6366f1'];

const MarketAnalysisPanel: React.FC<{ marketData: MarketData }> = ({ marketData }) => {
    const model = marketData.hybridEnsemblePrediction;
    return (
        <Card>
             <div className="mb-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-2">Key Takeaways</h3>
                <p className="text-sm text-slate-600 leading-relaxed" dangerouslySetInnerHTML={{ __html: marketData.keyTakeaways.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
            </div>

            <div className="mb-6 border-t pt-4">
                <h3 className="text-lg font-semibold text-slate-800 mb-2 flex items-center">
                    <ChartBarIcon className="w-5 h-5 mr-2" />
                    Feature Importance
                </h3>
                <div className="h-48 w-full">
                    <ResponsiveContainer>
                        <BarChart layout="vertical" data={marketData.featureImportance} margin={{ top: 5, right: 20, left: 80, bottom: 5 }}>
                            <XAxis type="number" hide />
                            <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 12, fill: '#475569' }} />
                            <Tooltip formatter={(value: number) => `${value.toFixed(1)}%`} cursor={{ fill: '#f1f5f9' }} />
                            <Bar dataKey="value" name="Importance" barSize={20}>
                                {marketData.featureImportance.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="border-t pt-4 mb-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-2 flex items-center">
                    <CpuChipIcon className="w-5 h-5 mr-2" />
                    Model Performance
                </h3>
                {model ? (
                    <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-4 gap-1 items-center bg-slate-50 p-2 rounded-md">
                            <span className="font-medium text-slate-700 col-span-1">{model.name}</span>
                            <span className="text-xs text-slate-500 text-center">MSE: {model.mse.toFixed(3)}</span>
                            <span className="text-xs text-slate-500 text-center">RMSE: {model.rmse.toFixed(3)}</span>
                            <span className="font-bold text-indigo-600 text-right">{model.predictedVolatility.toFixed(2)}% Vol</span>
                        </div>
                    </div>
                ) : <p className="text-sm text-slate-500">Model data not available.</p>}
            </div>

            <div className="border-t pt-4">
                <h3 className="text-lg font-semibold text-slate-800 mb-2 flex items-center">
                    <DocumentCheckIcon className="w-5 h-5 mr-2" />
                    VaR Backtesting
                </h3>
                <div className="grid grid-cols-3 gap-2 text-center">
                     <div>
                        <p className="text-xs font-medium text-slate-500">Actual Hits</p>
                        <p className="text-xl font-bold text-blue-600">{marketData.backtesting.varHitRate.toFixed(2)}%</p>
                    </div>
                     <div>
                        <p className="text-xs font-medium text-slate-500">Expected Hits</p>
                        <p className="text-xl font-bold text-slate-600">{marketData.backtesting.expectedHitRate.toFixed(2)}%</p>
                    </div>
                     <div>
                        <p className="text-xs font-medium text-slate-500">p-value</p>
                        <p className={`text-xl font-bold ${marketData.backtesting.kupiecPValue > 0.05 ? 'text-green-600' : 'text-amber-600'}`}>{marketData.backtesting.kupiecPValue.toFixed(3)}</p>
                    </div>
                </div>
            </div>
        </Card>
    );
};

export default MarketAnalysisPanel;