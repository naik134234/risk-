import React from 'react';
import type { MarketData, Scenario, ModelComplexity, AnalysisMode } from '../types';
import Card from './Card';
import ToggleSwitch from './ToggleSwitch';
import ScenarioSelector from './ScenarioSelector';
import ModelComplexitySelector from './ModelComplexitySelector';
import AnalysisModeSelector from './AnalysisModeSelector';

interface RiskMetricsPanelProps {
    marketData: MarketData | null;
    settings: {
        historicalPeriod: number;
        confidenceLevel: number;
        scenario: Scenario;
        modelComplexity: ModelComplexity;
        analysisMode: AnalysisMode;
    };
    setSettings: {
        setHistoricalPeriod: (p: number) => void;
        setConfidenceLevel: (c: number) => void;
        setScenario: (s: Scenario) => void;
        setModelComplexity: (c: ModelComplexity) => void;
        setAnalysisMode: (m: AnalysisMode) => void;
    };
    onAnalyze: () => void;
    autoRefresh: boolean;
    setAutoRefresh: (enabled: boolean) => void;
    lastUpdated: Date | null;
}

const MetricItem: React.FC<{ label: string; value: number | string | null; unit?: string, colorClass?: string }> = ({ label, value, unit = '%', colorClass = 'text-red-600' }) => (
    <div>
        <p className="text-xs font-medium text-slate-500 uppercase">{label}</p>
        <p className={`text-2xl font-bold ${colorClass}`}>
            {typeof value === 'number' ? `${value.toFixed(2)}${unit}` : '--'}
        </p>
    </div>
);


const MetricGroup: React.FC<{
    label: string;
    varValue: number | null;
    cvarValue: number | null;
    varColor?: string;
    cvarColor?: string;
}> = ({ label, varValue, cvarValue, varColor = 'text-red-600', cvarColor = 'text-red-800' }) => (
    <div>
        <h3 className="text-md font-semibold text-slate-700 mb-2">{label}</h3>
        <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <MetricItem label="VaR" value={varValue} colorClass={varColor} />
            <MetricItem label="CVaR (ES)" value={cvarValue} colorClass={cvarColor} />
        </div>
    </div>
);

const RiskMetricsPanel: React.FC<RiskMetricsPanelProps> = ({ marketData, settings, setSettings, onAnalyze, autoRefresh, setAutoRefresh, lastUpdated }) => {
    const isSimulationMode = settings.analysisMode === 'simulation';
    return (
        <Card>
            <h2 className="text-xl font-bold text-slate-700 mb-4">Analysis Controls</h2>
            
            <div className="space-y-4 mb-6">
                <AnalysisModeSelector selectedMode={settings.analysisMode} onSelectMode={setSettings.setAnalysisMode} />
                <ScenarioSelector selectedScenario={settings.scenario} onSelectScenario={setSettings.setScenario} disabled={!isSimulationMode} />
                <ModelComplexitySelector selectedComplexity={settings.modelComplexity} onSelectComplexity={setSettings.setModelComplexity} disabled={!isSimulationMode}/>
                 <div>
                    <label htmlFor="period" className="block text-sm font-medium text-slate-600 mb-1">Historical Period</label>
                    <select id="period" value={settings.historicalPeriod} onChange={(e) => setSettings.setHistoricalPeriod(Number(e.target.value))} className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                        <option value="60">60 Days</option>
                        <option value="180">180 Days</option>
                        <option value="365">1 Year</option>
                        <option value="730">2 Years</option>
                        <option value="1095">3 Years</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="confidence" className="block text-sm font-medium text-slate-600 mb-1">VaR Confidence Level</label>
                    <select id="confidence" value={settings.confidenceLevel} onChange={(e) => setSettings.setConfidenceLevel(Number(e.target.value))} className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                        <option value="99">99%</option>
                        <option value="95">95%</option>
                        <option value="90">90%</option>
                    </select>
                </div>
            </div>

            <div className="space-y-3 mb-6 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <ToggleSwitch label="Auto-Refresh (5 min)" enabled={autoRefresh} onChange={setAutoRefresh} />
                {lastUpdated && (
                    <p className="text-xs text-slate-500 text-center pt-2">
                        Last Updated: {lastUpdated.toLocaleTimeString()}
                    </p>
                )}
            </div>

            <button
                onClick={onAnalyze}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 transition-opacity shadow-lg mb-6"
            >
                Fetch & Analyze Data
            </button>

            <div className="space-y-4 border-t border-slate-200 pt-6">
                 <MetricGroup 
                    label="Historical"
                    varValue={marketData?.riskMetrics.historicVaR ?? null}
                    cvarValue={marketData?.riskMetrics.historicCVaR ?? null}
                />
                <MetricGroup 
                    label="Monte Carlo"
                    varValue={marketData?.riskMetrics.monteCarloVaR ?? null}
                    cvarValue={marketData?.riskMetrics.monteCarloCVaR ?? null}
                />
                 <MetricGroup 
                    label="AI Ensemble Model"
                    varValue={marketData?.riskMetrics.modelVaR ?? null}
                    cvarValue={marketData?.riskMetrics.modelCVaR ?? null}
                    varColor="text-purple-600"
                    cvarColor="text-purple-800"
                />
            </div>
        </Card>
    );
};

export default RiskMetricsPanel;