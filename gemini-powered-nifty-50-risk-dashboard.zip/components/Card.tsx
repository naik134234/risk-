
import React from 'react';

interface CardProps {
    children: React.ReactNode;
    className?: string;
    title?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', title }) => {
    return (
        <div className={`bg-white rounded-2xl shadow-md p-6 border border-slate-200 ${className}`}>
            {title && <h2 className="text-xl font-bold text-slate-700 mb-4">{title}</h2>}
            {children}
        </div>
    );
};

export default Card;
