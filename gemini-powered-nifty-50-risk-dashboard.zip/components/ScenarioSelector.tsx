import React from 'react';
import type { Scenario } from '../types';
import { RocketLaunchIcon, ArrowTrendingDownIcon, BoltIcon, ChartPieIcon } from './Icons';

interface ScenarioSelectorProps {
    selectedScenario: Scenario;
    onSelectScenario: (scenario: Scenario) => void;
    disabled?: boolean;
}

const scenarios: { id: Scenario; label: string; icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
    { id: 'normal', label: 'Normal', icon: ChartPieIcon },
    { id: 'bullish', label: 'Bullish', icon: RocketLaunchIcon },
    { id: 'bearish', label: 'Bearish', icon: ArrowTrendingDownIcon },
    { id: 'volatile', label: 'Volatile', icon: BoltIcon },
];

const ScenarioSelector: React.FC<ScenarioSelectorProps> = ({ selectedScenario, onSelectScenario, disabled = false }) => {
    return (
        <div className={disabled ? 'opacity-50 pointer-events-none' : ''}>
            <label className="block text-sm font-medium text-slate-600 mb-2">Market Scenario Simulation</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 rounded-lg bg-slate-100 p-1">
                {scenarios.map((scenario) => (
                    <button
                        key={scenario.id}
                        onClick={() => onSelectScenario(scenario.id)}
                        disabled={disabled}
                        className={`w-full flex flex-col items-center justify-center px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 focus:ring-indigo-500
                            ${selectedScenario === scenario.id
                                ? 'bg-white text-indigo-700 shadow'
                                : 'bg-transparent text-slate-600 hover:bg-slate-200'
                            }`}
                    >
                        <scenario.icon className="w-5 h-5 mb-1" />
                        {scenario.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default ScenarioSelector;