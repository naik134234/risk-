import React, { useState, useMemo } from 'react';
import type { Stock, PortfolioStock, MarketData } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import Card from './Card';
import { BeakerIcon, TrashIcon, CalculatorIcon } from './Icons';

interface PortfolioPanelProps {
    niftyStocks: Stock[];
    selectedStocks: PortfolioStock[];
    setSelectedStocks: React.Dispatch<React.SetStateAction<PortfolioStock[]>>;
    marketData: MarketData;
    onAnalyzePortfolio: () => void;
    isAnalyzingPortfolio: boolean;
    confidenceLevel: number;
}

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#6366f1', '#ec4899', '#3b82f6'];

/**
 * Calculates a stressed Value at Risk (VaR) by applying market shocks to a historical return series.
 * @param returns - Array of historical daily returns (e.g., 0.01 for 1%).
 * @param confidence - The confidence level for VaR (e.g., 95).
 * @param drop - The percentage drop to simulate as a market shock.
 * @param volSurge - The percentage increase in volatility to simulate.
 * @returns The calculated stressed VaR as a percentage.
 */
const calculateStressedVaR = (
    returns: number[],
    confidence: number,
    drop: number,
    volSurge: number
): number => {
    if (returns.length === 0) return 0;

    // 1. Apply Volatility Surge: Increase the standard deviation of returns.
    const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
    const scalingFactor = 1 + volSurge / 100;
    let stressedReturns = returns.map(r => mean + (r - mean) * scalingFactor);

    // 2. Apply Market Drop Shock: Add a single large negative return event.
    stressedReturns.push(-drop / 100);

    // 3. Calculate VaR from the new stressed distribution of losses.
    const losses = stressedReturns.map(r => -r * 100); // Convert to percentage loss
    losses.sort((a, b) => b - a);
    
    const varIndex = Math.ceil(losses.length * (1 - confidence / 100)) - 1;
    const varValue = losses[varIndex > -1 ? varIndex : 0] || 0;

    return parseFloat(varValue.toFixed(2));
};


const PortfolioPanel: React.FC<PortfolioPanelProps> = ({ niftyStocks, selectedStocks, setSelectedStocks, marketData, onAnalyzePortfolio, isAnalyzingPortfolio, confidenceLevel }) => {
    const [stressNiftyDrop, setStressNiftyDrop] = useState(10);
    const [stressVolSurge, setStressVolSurge] = useState(50);
    const [stressVaR, setStressVaR] = useState<number | null>(null);

    const handleAddStock = (stockName: string) => {
        if (stockName && !selectedStocks.some(s => s.name === stockName)) {
            const stockToAdd = niftyStocks.find(s => s.name === stockName);
            if (stockToAdd) {
                const newSelection = [...selectedStocks, { ...stockToAdd, weight: 0 }];
                autoBalanceWeights(newSelection);
            }
        }
    };

    const handleRemoveStock = (stockName: string) => {
        const newSelection = selectedStocks.filter(s => s.name !== stockName);
        autoBalanceWeights(newSelection);
    };

    const handleWeightChange = (stockName: string, weight: number) => {
        const newSelection = selectedStocks.map(s =>
            s.name === stockName ? { ...s, weight: isNaN(weight) ? 0 : weight } : s
        );
        setSelectedStocks(newSelection);
    };

    const autoBalanceWeights = (selection: PortfolioStock[]) => {
        const totalWeight = 100;
        const newWeight = selection.length > 0 ? totalWeight / selection.length : 0;
        const balancedSelection = selection.map(s => ({ ...s, weight: parseFloat(newWeight.toFixed(1)) }));
        setSelectedStocks(balancedSelection);
    };
    
    const runStressTest = () => {
        if (!marketData?.dailyReturns) {
            setStressVaR(0);
            return;
        }

        const newStressVaR = calculateStressedVaR(
            marketData.dailyReturns,
            confidenceLevel,
            stressNiftyDrop,
            stressVolSurge
        );

        setStressVaR(newStressVaR);
    };

    const totalWeight = useMemo(() => selectedStocks.reduce((sum, s) => sum + s.weight, 0), [selectedStocks]);

    return (
        <Card title="Portfolio & Stress Testing">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Portfolio Builder */}
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-semibold text-slate-800">Portfolio Builder</h3>
                        <button
                            onClick={onAnalyzePortfolio}
                            disabled={selectedStocks.length < 2 || isAnalyzingPortfolio}
                            className="flex items-center text-sm font-semibold px-3 py-1 rounded-full bg-indigo-50 hover:bg-indigo-100 text-indigo-600 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed transition-colors"
                            title={selectedStocks.length < 2 ? "Select at least 2 stocks" : "Analyze portfolio correlation"}
                        >
                            {isAnalyzingPortfolio ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <CalculatorIcon className="w-4 h-4 mr-2" />
                                    Analyze Correlation
                                </>
                            )}
                        </button>
                    </div>
                    <div className="mb-4">
                        <select onChange={(e) => handleAddStock(e.target.value)} className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 mb-2">
                            <option value="">Add a stock to your portfolio...</option>
                            {niftyStocks.filter(ns => !selectedStocks.some(ss => ss.name === ns.name)).map(stock => (
                                <option key={stock.name} value={stock.name}>{stock.name} ({stock.sector})</option>
                            ))}
                        </select>
                    </div>
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                        {selectedStocks.map(stock => (
                            <div key={stock.name} className="flex items-center space-x-2 bg-slate-50 p-2 rounded-md">
                                <span className="flex-grow text-sm font-medium text-slate-700">{stock.name}</span>
                                <input
                                    type="number"
                                    value={stock.weight}
                                    onChange={(e) => handleWeightChange(stock.name, parseFloat(e.target.value))}
                                    className="w-20 p-1 border border-slate-300 rounded-md text-center"
                                />
                                <button onClick={() => handleRemoveStock(stock.name)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5" /></button>
                            </div>
                        ))}
                    </div>
                     {selectedStocks.length > 0 && (
                        <div className={`mt-2 text-sm font-bold ${Math.abs(totalWeight - 100) > 0.1 ? 'text-red-500' : 'text-green-600'}`}>
                            Total Weight: {totalWeight.toFixed(1)}%
                        </div>
                    )}
                </div>

                {/* Risk Contribution */}
                 <div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-2">Sector Risk Contribution</h3>
                     <div className="h-48 w-full">
                        <ResponsiveContainer>
                           <PieChart>
                                <Pie data={marketData.riskContribution.bySector} dataKey="contribution" nameKey="sector" cx="50%" cy="50%" outerRadius={60} label>
                                     {marketData.riskContribution.bySector.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(value: number, name) => [`${value.toFixed(1)}%`, name]}/>
                                <Legend wrapperStyle={{fontSize: "12px"}}/>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                    
                    <div className="mt-6">
                        <h3 className="text-lg font-semibold text-slate-800 mb-2">Stock Risk Contribution</h3>
                        <div className="h-48 w-full">
                            <ResponsiveContainer>
                                <BarChart layout="vertical" data={marketData.riskContribution.byStock} margin={{ top: 5, right: 20, left: 100, bottom: 5 }}>
                                    <XAxis type="number" hide />
                                    <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 12, fill: '#475569' }} />
                                    <Tooltip formatter={(value: number) => `${value.toFixed(1)}%`} cursor={{ fill: '#f1f5f9' }} />
                                    <Bar dataKey="contribution" name="Contribution" barSize={15}>
                                        {marketData.riskContribution.byStock.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>


                {/* Stress Testing */}
                <div className="md:col-span-2 border-t pt-6 mt-6">
                     <h3 className="text-lg font-semibold text-slate-800 mb-4">Stress Testing</h3>
                     <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                         <div>
                             <label className="block text-sm font-medium text-slate-600">NIFTY Drop (%)</label>
                             <input type="number" value={stressNiftyDrop} onChange={(e) => setStressNiftyDrop(Number(e.target.value))} className="w-full p-2 border border-slate-300 rounded-lg mt-1" />
                         </div>
                         <div>
                             <label className="block text-sm font-medium text-slate-600">Volatility Surge (%)</label>
                             <input type="number" value={stressVolSurge} onChange={(e) => setStressVolSurge(Number(e.target.value))} className="w-full p-2 border border-slate-300 rounded-lg mt-1" />
                         </div>
                         <button onClick={runStressTest} className="w-full bg-amber-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-amber-600 transition-colors flex items-center justify-center">
                            <BeakerIcon className="w-5 h-5 mr-2" />
                             Run Test
                         </button>
                     </div>
                     <div className="mt-4 h-52 w-full bg-slate-50 p-4 rounded-lg">
                        <ResponsiveContainer>
                           <BarChart data={[
                               { name: 'Current VaR', value: marketData.riskMetrics.historicVaR },
                               { name: 'Stressed VaR', value: stressVaR }
                           ]}>
                                <XAxis dataKey="name" tick={{ fill: '#475569' }}/>
                                <YAxis tick={{ fill: '#475569' }} unit="%" />
                                <Tooltip formatter={(value: number) => `${value.toFixed(2)}%`} cursor={{ fill: '#f1f5f9' }} />
                                <Bar dataKey="value" name="VaR">
                                     <Cell fill="#6366f1" />
                                     <Cell fill="#f43f5e" />
                                </Bar>
                           </BarChart>
                        </ResponsiveContainer>
                     </div>
                </div>
            </div>
        </Card>
    );
};

export default PortfolioPanel;