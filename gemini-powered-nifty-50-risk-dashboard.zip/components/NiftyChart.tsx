import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { MarketData } from '../types';
import Card from './Card';

interface NiftyChartProps {
    data: MarketData;
}

const NiftyChart: React.FC<NiftyChartProps> = ({ data }) => {
    const chartData = data.performanceData.map((point, index) => ({
        ...point,
        sma10: data.sma10[index],
    }));

    return (
        <Card title="NIFTY 50 Performance & Volatility">
            <div className="h-96 w-full">
                <ResponsiveContainer>
                    <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="day" tick={{ fill: '#64748b' }} />
                        <YAxis yAxisId="left" tickFormatter={(value) => `₹${value.toLocaleString()}`} tick={{ fill: '#64748b' }} />
                        <YAxis yAxisId="right" orientation="right" tickFormatter={(value) => `${value}%`} tick={{ fill: '#64748b' }} />
                        <Tooltip
                            contentStyle={{
                                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                                backdropFilter: 'blur(5px)',
                                border: '1px solid #e2e8f0',
                                borderRadius: '0.5rem',
                            }}
                            labelStyle={{ fontWeight: 'bold' }}
                        />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="price" name="NIFTY 50 Price" stroke="#4f46e5" strokeWidth={2} dot={false} />
                        <Line yAxisId="left" type="monotone" dataKey="sma10" name="10-Day SMA" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                        <Line yAxisId="right" type="monotone" dataKey="volatility" name="Realized Volatility" stroke="#f43f5e" strokeWidth={2} dot={false} />
                        <Line yAxisId="right" type="monotone" dataKey="impliedVolatility" name="Implied Volatility" stroke="#f97316" strokeWidth={2} strokeDasharray="3 3" dot={false} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </Card>
    );
};

export default NiftyChart;