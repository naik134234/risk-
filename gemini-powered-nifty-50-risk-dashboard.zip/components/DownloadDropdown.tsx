import React, { useState, useRef, useEffect } from 'react';
import { ArrowDownTrayIcon, ChevronDownIcon } from './Icons';

type DownloadFormat = 'json' | 'excel' | 'html';

interface DownloadDropdownProps {
    onSelectFormat: (format: DownloadFormat) => void;
    isDisabled: boolean;
}

const DownloadDropdown: React.FC<DownloadDropdownProps> = ({ onSelectFormat, isDisabled }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (format: DownloadFormat) => {
        onSelectFormat(format);
        setIsOpen(false);
    };

    return (
        <div className="relative inline-block text-left" ref={dropdownRef}>
            <div>
                <button
                    type="button"
                    onClick={() => setIsOpen(!isOpen)}
                    disabled={isDisabled}
                    className="flex items-center justify-center w-full px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    aria-haspopup="true"
                    aria-expanded={isOpen}
                    aria-label="Download report options"
                >
                    <ArrowDownTrayIcon className="w-5 h-5 mr-2" />
                    Download Report
                    <ChevronDownIcon className="w-5 h-5 ml-2 -mr-1" />
                </button>
            </div>
            
            {isOpen && (
                <div
                    className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="menu-button"
                >
                    <div className="py-1" role="none">
                        <a
                            href="#"
                            onClick={(e) => { e.preventDefault(); handleSelect('json'); }}
                            className="text-slate-700 block px-4 py-2 text-sm hover:bg-slate-100"
                            role="menuitem"
                        >
                           Download as JSON
                        </a>
                        <a
                            href="#"
                            onClick={(e) => { e.preventDefault(); handleSelect('excel'); }}
                            className="text-slate-700 block px-4 py-2 text-sm hover:bg-slate-100"
                            role="menuitem"
                        >
                            Download as Excel (CSV)
                        </a>
                        <a
                            href="#"
                            onClick={(e) => { e.preventDefault(); handleSelect('html'); }}
                            className="text-slate-700 block px-4 py-2 text-sm hover:bg-slate-100"
                            role="menuitem"
                        >
                            Download as HTML
                        </a>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DownloadDropdown;
