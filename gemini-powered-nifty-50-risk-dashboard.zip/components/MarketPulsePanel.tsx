
import React from 'react';
import type { MarketData } from '../types';
import Card from './Card';
import { GlobeAltIcon, NewspaperIcon, ChartBarIcon } from './Icons';

const MarketPulsePanel: React.FC<{ marketData: MarketData }> = ({ marketData }) => {
    return (
        <Card>
            <div className="mb-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center">
                    <ChartBarIcon className="w-5 h-5 mr-2" />
                    Top Performers
                </h3>
                <ul className="space-y-2 text-sm max-h-40 overflow-y-auto pr-2">
                    {marketData.topPerformers.map(p => (
                        <li key={p.name} className="flex justify-between items-center">
                            <span className="font-medium text-slate-700">{p.name}</span>
                            <span className={`font-bold ${p.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {p.change >= 0 ? '+' : ''}{p.change.toFixed(2)}%
                            </span>
                        </li>
                    ))}
                </ul>
            </div>
            
            <div className="mb-6 border-t pt-4">
                <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center">
                    <NewspaperIcon className="w-5 h-5 mr-2" />
                    Market Events
                </h3>
                <ul className="space-y-2 text-sm text-slate-600 list-disc list-inside">
                    {marketData.marketEvents.map((event, index) => (
                        <li key={index}>{event}</li>
                    ))}
                </ul>
            </div>

            <div className="border-t pt-4">
                <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center">
                    <GlobeAltIcon className="w-5 h-5 mr-2" />
                    Macro Indicators
                </h3>
                <div className="grid grid-cols-3 gap-2 text-center">
                     <div>
                        <p className="text-xs font-medium text-slate-500">CPI</p>
                        <p className="text-lg font-bold text-indigo-600">{marketData.macroIndicators.cpi.toFixed(2)}%</p>
                    </div>
                     <div>
                        <p className="text-xs font-medium text-slate-500">Repo Rate</p>
                        <p className="text-lg font-bold text-indigo-600">{marketData.macroIndicators.repoRate.toFixed(2)}%</p>
                    </div>
                     <div>
                        <p className="text-xs font-medium text-slate-500">GDP</p>
                        <p className="text-lg font-bold text-indigo-600">{marketData.macroIndicators.gdp.toFixed(2)}%</p>
                    </div>
                </div>
            </div>
        </Card>
    );
};

export default MarketPulsePanel;
