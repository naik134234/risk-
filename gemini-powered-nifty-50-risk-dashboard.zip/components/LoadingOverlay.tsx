import React from 'react';
import type { AnalysisMode } from '../types';

interface LoadingOverlayProps {
    analysisMode: AnalysisMode;
}

const messages = {
    simulation: {
        title: 'Generating AI-Powered Market Simulation...',
        subtitle: 'This may take a moment.'
    },
    historical: {
        title: 'Fetching & Analyzing Historical Data...',
        subtitle: 'Please wait while we process real market history.'
    }
};

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ analysisMode }) => {
    const { title, subtitle } = messages[analysisMode];

    return (
        <div className="fixed inset-0 bg-slate-900 bg-opacity-60 backdrop-blur-sm flex flex-col justify-center items-center z-50 transition-opacity duration-300">
            <div className="w-16 h-16 border-4 border-slate-300 border-t-indigo-500 rounded-full animate-spin"></div>
            <p className="mt-4 text-white text-lg font-semibold">{title}</p>
            <p className="text-slate-300">{subtitle}</p>
        </div>
    );
};

export default LoadingOverlay;