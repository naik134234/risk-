
import React from 'react';
import type { Alert } from '../types';
import Card from './Card';
import { BellIcon, ExclamationTriangleIcon, InformationCircleIcon, XCircleIcon } from './Icons';

const alertConfig = {
    info: {
        icon: <InformationCircleIcon className="w-5 h-5 text-blue-500" />,
        style: 'bg-blue-50 border-blue-400',
    },
    warning: {
        icon: <ExclamationTriangleIcon className="w-5 h-5 text-amber-500" />,
        style: 'bg-amber-50 border-amber-400',
    },
    critical: {
        icon: <XCircleIcon className="w-5 h-5 text-red-500" />,
        style: 'bg-red-50 border-red-400',
    },
};

const AlertsPanel: React.FC<{ alerts: Alert[]; onClear: () => void; }> = ({ alerts, onClear }) => {
    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-slate-700 flex items-center">
                    <BellIcon className="w-6 h-6 mr-2" />
                    Live Alerts
                </h2>
                <button onClick={onClear} className="text-sm text-slate-500 hover:text-slate-800">Clear</button>
            </div>
            <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                {alerts.length > 0 ? (
                    alerts.map((alert, index) => (
                        <div key={index} className={`p-3 rounded-lg border-l-4 flex items-start space-x-3 ${alertConfig[alert.type].style}`}>
                            <div className="flex-shrink-0 pt-0.5">
                                {alertConfig[alert.type].icon}
                            </div>
                            <div>
                                <p className="text-sm text-slate-700">{alert.message}</p>
                                <p className="text-xs text-slate-500">{alert.timestamp}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-sm text-slate-500 text-center py-4">No new alerts.</p>
                )}
            </div>
        </Card>
    );
};

export default AlertsPanel;
