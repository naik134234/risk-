import React, { useState, useEffect, useRef } from 'react';
import Card from './Card';
import { SparklesIcon, PaperAirplaneIcon, TrashIcon } from './Icons';
import type { ChatMessage } from '../types';

interface ChatPanelProps {
    history: ChatMessage[];
    isChatting: boolean;
    onSendMessage: (message: string) => void;
    error: string | null;
    onClearChat: () => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ history, isChatting, onSendMessage, error, onClearChat }) => {
    const [input, setInput] = useState('');
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [history]);

    const handleSubmit = (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        const trimmedInput = input.trim();
        if (trimmedInput && !isChatting) {
            onSendMessage(trimmedInput);
            setInput('');
        }
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    };

    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-slate-700 flex items-center">
                    <SparklesIcon className="w-6 h-6 mr-2 text-indigo-500" />
                    AI Financial Analyst
                </h2>
                <button onClick={onClearChat} className="text-sm text-slate-500 hover:text-slate-800" title="Clear chat history">
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
            
            <div ref={chatContainerRef} className="h-96 overflow-y-auto pr-2 space-y-4 mb-4 flex flex-col">
                {history.map((msg, index) => (
                    <div key={index} className={`flex items-start gap-3 max-w-sm md:max-w-md ${msg.role === 'user' ? 'self-end' : 'self-start'}`}>
                        {msg.role === 'model' && (
                             <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex-shrink-0 flex items-center justify-center text-white">
                                <SparklesIcon className="w-5 h-5"/>
                             </div>
                        )}
                        <div className={`rounded-2xl p-3 text-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'}`}>
                           <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: msg.parts.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />') }} />
                            {isChatting && msg.role === 'model' && index === history.length - 1 && (
                                <div className="inline-block w-1.5 h-1.5 bg-slate-500 rounded-full ml-1 animate-pulse"></div>
                            )}
                        </div>
                    </div>
                ))}
                {error && (
                     <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md text-sm">
                        <p><strong>Error:</strong> {error}</p>
                    </div>
                )}
            </div>

            <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t pt-4">
                <textarea
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask NIFTY-AI anything..."
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-100 transition-all resize-none"
                    rows={1}
                    disabled={isChatting}
                    aria-label="Chat message input"
                />
                <button
                    type="submit"
                    disabled={isChatting || !input.trim()}
                    className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                    aria-label="Send message"
                >
                    <PaperAirplaneIcon className="w-5 h-5"/>
                </button>
            </form>
        </Card>
    );
};

export default ChatPanel;