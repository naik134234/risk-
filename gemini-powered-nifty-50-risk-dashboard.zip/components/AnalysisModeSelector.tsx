import React from 'react';
import type { AnalysisMode } from '../types';
import { CpuChipIcon, PresentationChartBarIcon } from './Icons';

interface AnalysisModeSelectorProps {
    selectedMode: AnalysisMode;
    onSelectMode: (mode: AnalysisMode) => void;
}

const modes: { id: AnalysisMode; label: string; icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
    { id: 'simulation', label: 'AI Simulation', icon: CpuChipIcon },
    { id: 'historical', label: 'Historical Data', icon: PresentationChartBarIcon },
];

const AnalysisModeSelector: React.FC<AnalysisModeSelectorProps> = ({ selectedMode, onSelectMode }) => {
    return (
        <div>
            <label className="block text-sm font-medium text-slate-600 mb-2">Analysis Mode</label>
            <div className="grid grid-cols-2 gap-2 rounded-lg bg-slate-100 p-1">
                {modes.map((mode) => (
                    <button
                        key={mode.id}
                        onClick={() => onSelectMode(mode.id)}
                        className={`w-full flex flex-col items-center justify-center px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 focus:ring-indigo-500
                            ${selectedMode === mode.id
                                ? 'bg-white text-indigo-700 shadow'
                                : 'bg-transparent text-slate-600 hover:bg-slate-200'
                            }`}
                    >
                        <mode.icon className="w-5 h-5 mb-1" />
                        {mode.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default AnalysisModeSelector;