
import React, { useMemo } from 'react';
import Card from './Card';
import { TrendingUpIcon, TrendingDownIcon, MinusIcon } from './Icons';

interface MarketSentimentPanelProps {
    sentiment: string;
}

const MarketSentimentPanel: React.FC<MarketSentimentPanelProps> = ({ sentiment }) => {
    const sentimentAnalysis = useMemo(() => {
        const lowerSentiment = sentiment.toLowerCase();
        if (lowerSentiment.includes('bullish') || lowerSentiment.includes('optimistic') || lowerSentiment.includes('positive')) {
            return {
                Icon: TrendingUpIcon,
                colorClass: 'border-green-500 bg-green-50 text-green-800',
                iconClass: 'text-green-500'
            };
        }
        if (lowerSentiment.includes('bearish') || lowerSentiment.includes('pessimistic') || lowerSentiment.includes('negative')) {
            return {
                Icon: TrendingDownIcon,
                colorClass: 'border-red-500 bg-red-50 text-red-800',
                iconClass: 'text-red-500'
            };
        }
        return {
            Icon: MinusIcon,
            colorClass: 'border-slate-500 bg-slate-50 text-slate-800',
            iconClass: 'text-slate-500'
        };
    }, [sentiment]);

    return (
        <Card className={`border-l-4 ${sentimentAnalysis.colorClass}`}>
            <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-full ${sentimentAnalysis.colorClass}`}>
                    <sentimentAnalysis.Icon className={`w-8 h-8 ${sentimentAnalysis.iconClass}`} />
                </div>
                <div>
                    <h3 className="text-sm font-medium text-slate-500">Market Sentiment</h3>
                    <p className="text-lg font-bold">{sentiment}</p>
                </div>
            </div>
        </Card>
    );
};

export default MarketSentimentPanel;
