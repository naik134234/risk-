import React from 'react';
import type { ModelComplexity } from '../types';
import { BoltIcon, ScaleIcon, CpuChipIcon } from './Icons';

interface ModelComplexitySelectorProps {
    selectedComplexity: ModelComplexity;
    onSelectComplexity: (complexity: ModelComplexity) => void;
    disabled?: boolean;
}

const complexities: { id: ModelComplexity; label: string; icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
    { id: 'fast', label: 'Fast', icon: BoltIcon },
    { id: 'balanced', label: 'Balanced', icon: ScaleIcon },
    { id: 'deep', label: 'Deep', icon: CpuChipIcon },
];

const ModelComplexitySelector: React.FC<ModelComplexitySelectorProps> = ({ selectedComplexity, onSelectComplexity, disabled = false }) => {
    return (
        <div className={disabled ? 'opacity-50 pointer-events-none' : ''}>
            <label className="block text-sm font-medium text-slate-600 mb-2">AI Model Complexity</label>
            <div className="grid grid-cols-3 gap-2 rounded-lg bg-slate-100 p-1">
                {complexities.map((complexity) => (
                    <button
                        key={complexity.id}
                        onClick={() => onSelectComplexity(complexity.id)}
                        disabled={disabled}
                        className={`w-full flex flex-col items-center justify-center px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 focus:ring-indigo-500
                            ${selectedComplexity === complexity.id
                                ? 'bg-white text-indigo-700 shadow'
                                : 'bg-transparent text-slate-600 hover:bg-slate-200'
                            }`}
                    >
                        <complexity.icon className="w-5 h-5 mb-1" />
                        {complexity.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default ModelComplexitySelector;