import React from 'react';
import DownloadDropdown from './DownloadDropdown';
import type { Scenario, AnalysisMode } from '../types';

type DownloadFormat = 'json' | 'excel' | 'html';

interface HeaderProps {
    onDownload: (format: DownloadFormat) => void;
    isDownloadDisabled: boolean;
    scenario: Scenario;
    analysisMode: AnalysisMode;
}

const scenarioConfig = {
    normal: { label: 'Normal Conditions', className: 'bg-slate-100 text-slate-600' },
    bullish: { label: 'Bullish Rally', className: 'bg-green-100 text-green-700' },
    bearish: { label: 'Bearish Recession', className: 'bg-red-100 text-red-700' },
    volatile: { label: 'High Volatility', className: 'bg-amber-100 text-amber-700' },
};

const Header: React.FC<HeaderProps> = ({ onDownload, isDownloadDisabled, scenario, analysisMode }) => {
    const currentScenario = scenarioConfig[scenario];

    return (
        <header className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div>
                <h1 className="text-3xl font-extrabold text-slate-800">
                    NIFTY 50 Risk Management Dashboard
                </h1>
                <div className="flex items-center gap-x-4 mt-1">
                     <p className="text-slate-500">Powered by Gemini AI</p>
                    {analysisMode === 'simulation' ? (
                        <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${currentScenario.className}`}>
                            Scenario: {currentScenario.label}
                        </span>
                    ) : (
                         <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-700`}>
                            Mode: Historical Analysis
                        </span>
                    )}
                </div>
            </div>
            <div className="mt-4 md:mt-0">
                <DownloadDropdown onSelectFormat={onDownload} isDisabled={isDownloadDisabled} />
            </div>
        </header>
    );
};

export default Header;