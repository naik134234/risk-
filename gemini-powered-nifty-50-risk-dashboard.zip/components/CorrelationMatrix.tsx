import React from 'react';
import type { MarketData } from '../types';
import Card from './Card';
import { LinkIcon } from './Icons';

interface CorrelationMatrixProps {
    marketData: MarketData;
}

const getCorrelationColor = (value: number) => {
    if (value === 1) return 'bg-slate-200 text-slate-500'; // Diagonal
    // Scale opacity for non-diagonal values
    const opacity = Math.abs(value) * 0.8 + 0.2; // From 20% to 100%
    if (value > 0) {
        return `bg-green-600/${Math.round(opacity*100)}`;
    }
    if (value < 0) {
        return `bg-red-600/${Math.round(opacity*100)}`;
    }
    return 'bg-slate-100'; // For 0 correlation
};


const CorrelationMatrix: React.FC<CorrelationMatrixProps> = ({ marketData }) => {
    const { stocks, matrix } = marketData.correlationMatrix;

    if (!stocks || !matrix || stocks.length === 0) {
        return null;
    }

    return (
        <Card>
            <h2 className="text-xl font-bold text-slate-700 mb-4 flex items-center">
                <LinkIcon className="w-6 h-6 mr-2" />
                Stock Correlation Matrix
            </h2>
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm text-center border-collapse">
                    <thead>
                        <tr>
                            <th className="p-2 border border-slate-200 bg-slate-100"></th>
                            {stocks.map(stock => (
                                <th key={stock} className="p-2 border border-slate-200 bg-slate-100 font-semibold text-slate-600 truncate" title={stock}>
                                    {stock}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {stocks.map((stock, rowIndex) => (
                            <tr key={stock}>
                                <th className="p-2 border border-slate-200 bg-slate-100 font-semibold text-slate-600 text-left truncate" title={stock}>
                                    {stock}
                                </th>
                                {matrix[rowIndex].map((value, colIndex) => (
                                    <td key={`${rowIndex}-${colIndex}`} className={`p-2 border border-slate-200 text-white font-bold ${getCorrelationColor(value)}`}>
                                        {value.toFixed(2)}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="flex justify-end items-center mt-4 text-xs space-x-4">
                 <div className="flex items-center"><span className="w-3 h-3 rounded-sm bg-green-600 mr-1"></span> Positive Correlation</div>
                 <div className="flex items-center"><span className="w-3 h-3 rounded-sm bg-red-600 mr-1"></span> Negative Correlation</div>
            </div>
        </Card>
    );
};

export default CorrelationMatrix;