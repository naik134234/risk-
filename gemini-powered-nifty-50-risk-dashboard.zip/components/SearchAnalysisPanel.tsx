import React from 'react';
import Card from './Card';
import { GlobeAltIcon, MagnifyingGlassIcon, LinkIcon } from './Icons';
import type { AnalysisResult } from '../types';

interface SearchAnalysisPanelProps {
    query: string;
    setQuery: (query: string) => void;
    onSearch: () => void;
    isSearching: boolean;
    result: AnalysisResult | null;
    error: string | null;
}

const SearchAnalysisPanel: React.FC<SearchAnalysisPanelProps> = ({ query, setQuery, onSearch, isSearching, result, error }) => {
    return (
        <Card>
            <h2 className="text-xl font-bold text-slate-700 mb-4 flex items-center">
                <GlobeAltIcon className="w-6 h-6 mr-2" />
                Live Market Analysis
            </h2>
            <div className="space-y-4">
                <div>
                    <textarea
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Ask about recent market trends, news, or a specific stock's outlook..."
                        className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-100"
                        rows={3}
                        disabled={isSearching}
                        aria-label="Market analysis query"
                    />
                </div>
                <button
                    onClick={onSearch}
                    disabled={isSearching || !query}
                    className="w-full bg-gradient-to-r from-sky-600 to-cyan-600 text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 transition-opacity shadow-lg flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isSearching ? (
                        <>
                            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            Searching...
                        </>
                    ) : (
                        <>
                            <MagnifyingGlassIcon className="w-5 h-5 mr-2" />
                            Search with AI
                        </>
                    )}
                </button>
            </div>
            <div className="mt-6">
                {error && (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                        <p className="font-bold">Error</p>
                        <p>{error}</p>
                    </div>
                )}
                {result && !error && (
                    <div className="space-y-4">
                        <div className="prose prose-sm max-w-none text-slate-600">
                             <p dangerouslySetInnerHTML={{ __html: result.text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />') }} />
                        </div>
                        {result.sources && result.sources.length > 0 && (
                             <div className="border-t pt-4">
                                <h4 className="text-sm font-semibold text-slate-700 mb-2">Sources</h4>
                                <ul className="space-y-2">
                                    {result.sources.map((source, index) => (
                                        <li key={index} className="flex items-start">
                                            <LinkIcon className="w-4 h-4 mr-2 mt-1 flex-shrink-0 text-slate-400" />
                                            <a
                                                href={source.web.uri}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-xs text-blue-600 hover:underline break-all"
                                                title={source.web.title}
                                            >
                                                {source.web.title || source.web.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </Card>
    );
};

export default SearchAnalysisPanel;
